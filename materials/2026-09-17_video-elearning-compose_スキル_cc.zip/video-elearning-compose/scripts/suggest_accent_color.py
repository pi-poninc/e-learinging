#!/usr/bin/env python3
"""
スライド画像から彩度の高い色を抽出し、テロップ背景色の候補を提案する。

黒背景そのままだと、テロップ用の余白（暗い単色キャンバス）に対してコントラストが
足りず「見にくい」と感じられやすい。スライドのデザインで使われているアクセントカラーを
少し暗く落として使うと、ブランドと馴染みつつ視認性も確保しやすい。

使い方:
  python3 suggest_accent_color.py <slide.png>

出力される候補色は「そのまま」ではなく、compose_video.py / prepare_assets.py の
--telop-bg-color に渡す前に、各チャンネルを0.6〜0.7倍程度暗くしたトーンにするのを推奨
（白文字とのコントラストを保ちつつ、キャンバスの暗さに負けない濃さにするため）。
"""

import sys
from collections import Counter
from pathlib import Path

from PIL import Image


def saturation(rgb):
    r, g, b = (c / 255 for c in rgb)
    mx, mn = max(r, g, b), min(r, g, b)
    return 0 if mx == 0 else (mx - mn) / mx


def main():
    if len(sys.argv) < 2:
        print("usage: suggest_accent_color.py <slide.png>", file=sys.stderr)
        sys.exit(1)

    path = Path(sys.argv[1])
    im = Image.open(path).convert("RGB").resize((160, 90))
    counts = Counter(im.getdata())

    candidates = sorted(counts.items(), key=lambda kv: -saturation(kv[0]) * kv[1])
    picked = []
    for rgb, _ in candidates:
        if saturation(rgb) < 0.15:
            continue
        hexcode = "#%02X%02X%02X" % rgb
        if hexcode not in picked:
            picked.append(hexcode)
        if len(picked) >= 5:
            break

    if not picked:
        print("彩度の高い色が見つかりませんでした（モノトーン系のスライドの可能性）。"
              "既定のダークウォームグレー（例: #3A352E〜#4A443C）を使ってください。")
        return

    print("スライドから抽出した彩度の高い色（上位5件）:")
    for h in picked:
        r, g, b = int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16)
        darker = "#%02X%02X%02X" % (round(r * 0.65), round(g * 0.65), round(b * 0.65))
        print(f"  元色 {h}  → テロップ背景の推奨トーン {darker}")


if __name__ == "__main__":
    main()
