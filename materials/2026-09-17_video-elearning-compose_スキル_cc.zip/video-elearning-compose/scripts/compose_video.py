#!/usr/bin/env python3
"""
prepare_assets.py が作った background.mp4 / captions.ass と、ナレーション音声、
（任意で）ワイプ動画を、最終レイアウトで1本のMP4に合成する。

レイアウトの考え方:
  スライドを画面に対して縮小し（既定で80パーセント）、画面の左上に隙間なく配置する。
  16:9のアスペクト比を保ったまま縮小するので、この1手で「右側の余白」と「下側の余白」が
  同時に生まれる（歪みなし）。ワイプはその右側の余白を隙間なく埋めるように配置し、
  テロップはその下側の余白に収める。結果として、スライド本体（見出し・カード・
  ターミナルモック・スライド自体の下部バーなど）とワイプ・テロップが構造的に絶対に
  重ならない。全画面スライドの上にワイプ/テロップを直接オーバーレイする方式は、
  スライドごとに内容の位置が違うため重なりチェックが必要になり壊れやすい——
  よほど理由がない限りこの「縮小して余白を作る」方式を使うこと。

使い方:
  python3 compose_video.py \
    --background background.mp4 --captions captions.ass --narration narration.mp3 \
    --out final.mp4 \
    [--wipe wipe.mp4] \
    [--width 1920] [--height 1080] \
    [--slide-scale 0.8] [--slide-x 0] [--slide-y 0] \
    [--canvas-color 0x141414] \
    [--wipe-margin 0] [--wipe-valign top|center|bottom]

ワイプなしで呼び出せば、スライド+テロップだけの動画になる（余白は残る＝テロップ用の
下側スペースは常に確保される）。
"""

import argparse
import subprocess
import sys
from pathlib import Path


def run(cmd, **kwargs):
    kwargs.setdefault("stdin", subprocess.DEVNULL)
    result = subprocess.run(cmd, capture_output=True, text=True, **kwargs)
    if result.returncode != 0:
        print(f"コマンド失敗: {' '.join(str(c) for c in cmd)}", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)
    return result


def get_duration(path):
    result = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                  "-of", "default=noprint_wrappers=1:nokey=1", str(path)])
    return float(result.stdout.strip())


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--background", required=True, help="prepare_assets.pyが作ったスライドショー動画")
    parser.add_argument("--captions", required=True, help="prepare_assets.pyが作ったASS字幕")
    parser.add_argument("--narration", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--wipe", default=None, help="画面録画・実演動画（任意）。指定しなければ配置しない")
    parser.add_argument("--width", type=int, default=1920)
    parser.add_argument("--height", type=int, default=1080)
    parser.add_argument("--slide-scale", type=float, default=0.8,
                         help="スライドを画面に対して何倍に縮小するか（0.8なら80%%）。小さくするほど余白が増える")
    parser.add_argument("--slide-x", type=int, default=0)
    parser.add_argument("--slide-y", type=int, default=0)
    parser.add_argument("--canvas-color", default="0x141414", help="余白部分の背景色")
    parser.add_argument("--wipe-margin", type=int, default=0,
                         help="ワイプと周囲の隙間(px)。0=スライド・画面端にぴったり密着")
    parser.add_argument("--wipe-valign", choices=["top", "center", "bottom"], default="top")
    args = parser.parse_args()

    background = Path(args.background).resolve()
    captions = Path(args.captions).resolve()
    narration = Path(args.narration).resolve()
    out_path = Path(args.out).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)

    duration = get_duration(narration)
    slide_w = round(args.width * args.slide_scale)
    slide_h = round(args.height * args.slide_scale)
    right_margin = args.width - args.slide_x - slide_w

    inputs = [
        "-f", "lavfi", "-i", f"color=c={args.canvas_color}:s={args.width}x{args.height}:r=25:d={duration + 0.5}",
        "-i", str(background),
    ]
    filters = [f"[1:v]scale={slide_w}:{slide_h}[slide]"]
    compose = f"[0:v][slide]overlay=x={args.slide_x}:y={args.slide_y}[c1]"
    filters.append(compose)
    last_label = "c1"
    audio_map_index = 2

    if args.wipe:
        wipe_path = Path(args.wipe).resolve()
        inputs += ["-i", str(wipe_path)]
        audio_map_index = 3
        wipe_w = right_margin - 2 * args.wipe_margin
        if wipe_w <= 0:
            print(f"エラー: ワイプ用の余白がありません（右余白{right_margin}px）。"
                  "--slide-scale を小さくするか --wipe-margin を減らしてください", file=sys.stderr)
            sys.exit(1)
        wipe_h = round(wipe_w * 9 / 16)
        wipe_x = args.slide_x + slide_w + args.wipe_margin
        if args.wipe_valign == "top":
            wipe_y = args.wipe_margin
        elif args.wipe_valign == "bottom":
            wipe_y = args.height - wipe_h - args.wipe_margin
        else:
            wipe_y = (args.height - wipe_h) // 2
        filters.append(f"[2:v]scale={wipe_w}:{wipe_h}[wipe]")
        filters.append(f"[{last_label}][wipe]overlay=x={wipe_x}:y={wipe_y}:shortest=1[c2]")
        last_label = "c2"

    filters.append(f"[{last_label}]ass='{captions}'[vout]")
    inputs += ["-i", str(narration)]

    filter_complex = "; ".join(filters)
    cmd = [
        "ffmpeg", "-nostdin", "-y",
        *inputs,
        "-filter_complex", filter_complex,
        "-map", "[vout]", "-map", f"{audio_map_index}:a",
        "-c:v", "libx264", "-crf", "18", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "192k",
        "-shortest", str(out_path),
    ]
    print("合成中...")
    run(cmd)
    print(f"完成: {out_path}")
    print(f"  スライド: {slide_w}x{slide_h} @ ({args.slide_x},{args.slide_y})")
    if args.wipe:
        print(f"  ワイプ: {wipe_w}x{wipe_h} @ ({wipe_x},{wipe_y})")
    print(f"  右余白: {right_margin}px / 下余白: {args.height - args.slide_y - slide_h}px")


if __name__ == "__main__":
    main()
