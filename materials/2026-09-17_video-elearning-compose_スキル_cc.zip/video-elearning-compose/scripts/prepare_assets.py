#!/usr/bin/env python3
"""
PPTXスライド + 台本Markdown + 収録済みナレーション音声から、
compose_video.py に渡すための素材（スライド画像・スライドショー背景動画・テロップASS・
スライド切り替えタイミング）を一括生成する。

前提コマンド（PATH上にあること）:
  soffice（LibreOffice）, pdftoppm（poppler）, ffmpeg, ffprobe, whisper-cli（whisper.cpp）

台本Markdownの形式（このVaultの `*_台本_cc.md` と同じ表形式を想定）:
  | # | スライド | ナレーション |
  |---|---|---|
  | 1 | 表紙 | こんにちは。... |
  | 2 | ... | ... |
  「ナレーション」という見出しを含む列を自動検出する（見つからなければ最終列を使う）。
  行数はスライド枚数と一致させること。

使い方:
  python3 prepare_assets.py \
    --pptx slides.pptx \
    --narration narration.mp3 \
    --script script.md \
    --workdir /path/to/workdir \
    [--whisper-model ~/.cache/whisper-cpp-models/ggml-large-v3-turbo.bin] \
    [--width 1920] [--height 1080] [--fps 25] \
    [--telop-font-size 42] [--telop-bg-color "#8C4A35"] [--telop-max-line-chars 26]

出力（workdir配下）:
  slides/slide-NN.png      … スライド画像
  background.mp4           … スライド切り替えタイミング通りに並べたスライドショー（無音）
  captions.ass             … テロップ字幕（whisperの文単位セグメントごとに1キュー）
  slide_timing.json        … 各スライドの開始/終了秒（要目視チェック。下記「注意」参照）
  transcript.json          … whisper生の文字起こし結果

注意:
  スライド切り替えタイミングは「台本の各行の書き出しが、文字起こし結果のどこに対応するか」を
  あいまい一致（difflib）で推定している。書き起こし精度や言い回しの揺れ次第でズレることがあるため、
  background.mp4 を作ったら数箇所フレームを抜き出して目視確認すること
  （例: ffmpeg -ss <秒> -i background.mp4 -frames:v 1 preview.png）。
  明らかにおかしい場合は slide_timing.json を手で編集し、build_slideshow_only を使って作り直せる。
"""

import argparse
import bisect
import difflib
import json
import subprocess
import sys
from pathlib import Path


def run(cmd, **kwargs):
    kwargs.setdefault("stdin", subprocess.DEVNULL)
    result = subprocess.run(cmd, capture_output=True, text=True, **kwargs)
    if result.returncode != 0:
        print(f"コマンド失敗: {' '.join(str(c) for c in cmd)}", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)
    return result


def convert_pptx_to_slides(pptx_path, workdir, width, height):
    run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", str(workdir), str(pptx_path)])
    pdf_path = workdir / (pptx_path.stem + ".pdf")
    if not pdf_path.exists():
        print(f"PDF変換に失敗した可能性があります: {pdf_path} が見つかりません", file=sys.stderr)
        sys.exit(1)
    slides_dir = workdir / "slides"
    slides_dir.mkdir(exist_ok=True)
    run([
        "pdftoppm", "-png", "-scale-to-x", str(width), "-scale-to-y", str(height),
        str(pdf_path), str(slides_dir / "slide"),
    ])
    slide_pngs = sorted(slides_dir.glob("slide-*.png"))
    if not slide_pngs:
        slide_pngs = sorted(slides_dir.glob("slide*.png"))
    return slide_pngs


def parse_script_table(md_text):
    """台本Markdownの表から「ナレーション」列だけを順番に抜き出す。"""
    lines = [l for l in md_text.splitlines() if l.strip().startswith("|")]
    if len(lines) < 2:
        raise ValueError("台本Markdown内に表（| ... | 形式）が見つかりません")

    header_cells = [c.strip() for c in lines[0].strip("|").split("|")]
    narration_idx = next((i for i, h in enumerate(header_cells) if "ナレーション" in h), None)
    if narration_idx is None:
        narration_idx = len(header_cells) - 1  # 見出しが見つからなければ最終列を仮定

    rows = []
    for line in lines[2:]:  # 1行目=見出し, 2行目=区切り(---)を想定してスキップ
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) <= narration_idx:
            continue
        text = cells[narration_idx]
        if not text or set(text) <= {"-"}:
            continue
        rows.append(text)
    if not rows:
        raise ValueError("台本Markdownの表からナレーション行を抽出できませんでした")
    return rows


def to_16k_mono_wav(narration_path, workdir):
    wav_path = workdir / "narration_16k.wav"
    run(["ffmpeg", "-nostdin", "-y", "-i", str(narration_path), "-ar", "16000", "-ac", "1",
         "-c:a", "pcm_s16le", str(wav_path)])
    return wav_path


def get_duration(path):
    result = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                  "-of", "default=noprint_wrappers=1:nokey=1", str(path)])
    return float(result.stdout.strip())


def transcribe(wav_path, model_path, workdir):
    out_prefix = workdir / "transcript"
    run(["whisper-cli", "-m", str(model_path), "-f", str(wav_path), "-l", "ja",
         "-oj", "-of", str(out_prefix)], stdin=subprocess.DEVNULL)
    transcript_json = out_prefix.with_suffix(".json")
    data = json.loads(transcript_json.read_text(encoding="utf-8"))
    segments = []
    for seg in data["transcription"]:
        text = seg["text"].strip()
        if not text:
            continue
        segments.append({
            "start": seg["offsets"]["from"] / 1000.0,
            "end": seg["offsets"]["to"] / 1000.0,
            "text": text,
        })
    return segments


def build_char_time_index(segments):
    """文字起こし全文の各文字位置に、線形補間した秒数を割り当てる。

    whisperのセグメント区切りが台本の行区切りと必ずしも一致しない
    （＝行の変わり目で明確な間が無いこともある）ケースのフォールバックに使う。
    """
    chars, times = [], []
    for seg in segments:
        text = seg["text"]
        n = len(text)
        for i, ch in enumerate(text):
            frac = i / max(n - 1, 1)
            chars.append(ch)
            times.append(seg["start"] + frac * (seg["end"] - seg["start"]))
    return "".join(chars), times


def match_slide_timings(segments, script_lines, total_duration,
                         prefix_len=25, window_sec=40.0, seg_min_score=0.40, char_min_ratio=0.3):
    """台本の各行が、文字起こしのどのセグメントから始まっているかを推定する。

    ナレーションは基本的に台本の行区切り＝間（ポーズ）と一致するので、whisperが
    区切ったセグメントの開始時刻にそのままスナップするのが最も精度が高い
    （文字単位で線形補間するより、実際の発話の切れ目に沿うため）。ただし2つの
    落とし穴があるため、単純な「残り全セグメントから最良スコアを選ぶ」方式は使わない：

    1. 「Claude Code」「MCP」のような英字の専門用語を、whisperがローマ字ではなく
       カタカナ（クロードコード等）や小文字（mcp等）で書き起こすことがあり、
       その行だけあいまい一致のスコアが極端に低くなる。無制限に全セグメントを
       探すと、たまたま別の場所のセグメントの方が高スコアになって誤爆する
       （実際、MCP解説編でこれが発生し添字エラーで落ちた）
    2. 行の変わり目でナレーターが間を取らないと、whisperのセグメントが2行分を
       1つに結合してしまい、行の開始位置がセグメントの真ん中に来ることがある

    対策として、台本の文字数比から算出した「だいたいこの時刻のはず」という
    予測時刻の前後 `window_sec` 秒だけを探索範囲にする（1の誤爆を防ぐ）。
    その範囲内でスコアが `seg_min_score` に届かない場合は、文字単位の線形補間
    （2に強い）にフォールバックする。
    """
    full_text, char_times = build_char_time_index(segments)
    total_chars = sum(len(l) for l in script_lines) or 1
    chars_per_sec = len(full_text) / total_duration if total_duration else 1.0
    window_chars = max(int(window_sec * chars_per_sec), 60)

    cum_chars = 0
    starts = []
    prev_start = 0.0
    for line in script_lines:
        expected_time = total_duration * (cum_chars / total_chars)
        cum_chars += len(line)
        prefix = line[:prefix_len]

        best_idx, best_score = None, -1.0
        for i, seg in enumerate(segments):
            if abs(seg["start"] - expected_time) > window_sec:
                continue
            score = difflib.SequenceMatcher(None, seg["text"][:prefix_len], prefix, autojunk=False).ratio()
            if score > best_score:
                best_score, best_idx = score, i

        if best_idx is not None and best_score >= seg_min_score:
            start = segments[best_idx]["start"]
        else:
            expected_idx = min(max(bisect.bisect_left(char_times, expected_time), 0), len(char_times) - 1)
            lo = max(0, expected_idx - window_chars)
            hi = min(len(full_text), expected_idx + window_chars)
            match = difflib.SequenceMatcher(None, full_text, prefix, autojunk=False).find_longest_match(
                lo, hi, 0, len(prefix))
            threshold = max(3, int(len(prefix) * char_min_ratio))
            if match.size >= threshold:
                est_idx = min(max(match.a - match.b, lo), hi - 1) if hi > lo else expected_idx
                start = char_times[est_idx]
            else:
                start = expected_time

        starts.append(max(start, prev_start))
        prev_start = starts[-1]

    timings = []
    for i, start in enumerate(starts):
        end = starts[i + 1] if i + 1 < len(starts) else total_duration
        timings.append({"slide": i + 1, "start": round(start, 3), "end": round(end, 3),
                         "text": script_lines[i]})
    return timings


def build_slideshow(slide_pngs, timings, width, height, fps, workdir):
    clips_dir = workdir / "clips"
    clips_dir.mkdir(exist_ok=True)
    clip_paths = []
    for i, (png, t) in enumerate(zip(slide_pngs, timings), start=1):
        duration = max(t["end"] - t["start"], 1 / fps)
        clip = clips_dir / f"clip-{i:02d}.mp4"
        run([
            "ffmpeg", "-nostdin", "-y", "-loop", "1", "-i", str(png),
            "-t", f"{duration:.3f}", "-r", str(fps), "-pix_fmt", "yuv420p",
            "-vf", f"scale={width}:{height}",
            "-c:v", "libx264", "-crf", "18", str(clip),
        ])
        clip_paths.append(clip)

    concat_list = workdir / "clips_list.txt"
    # concat demuxerに渡すリストは絶対パスにする（相対パスはnohup/バックグラウンド実行時に
    # cwdがずれて解決に失敗することがある）
    concat_list.write_text(
        "\n".join(f"file '{p.resolve()}'" for p in clip_paths), encoding="utf-8"
    )
    background = workdir / "background.mp4"
    run(["ffmpeg", "-nostdin", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_list),
         "-c", "copy", str(background)])
    return background


def hex_to_ass_color(hex_color):
    hex_color = hex_color.lstrip("#")
    r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
    return f"&H00{b:02X}{g:02X}{r:02X}"


def split_caption_line(text, limit):
    if len(text) <= limit:
        return [text]
    mid = len(text) // 2
    best = None
    for i, ch in enumerate(text):
        if ch in "、。":
            if best is None or abs(i - mid) < abs(best - mid):
                best = i
    if best is None:
        best = mid
    else:
        best += 1
    line1, line2 = text[:best].strip(), text[best:].strip()
    return [text] if not line1 or not line2 else [line1, line2]


def ass_timestamp(t):
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"


def build_captions_ass(segments, workdir, width, height, font_size, bg_color_hex, max_line_chars):
    bg_ass = hex_to_ass_color(bg_color_hex)
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Telop,Hiragino Sans,{font_size},&H00FFFFFF,&H00FFFFFF,{bg_ass},{bg_ass},1,0,0,0,100,100,0,0,3,8,0,2,80,80,40,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    lines = [header]
    for seg in segments:
        parts = split_caption_line(seg["text"], max_line_chars)
        body = "\\N".join(parts)
        lines.append(
            f"Dialogue: 0,{ass_timestamp(seg['start'])},{ass_timestamp(seg['end'])},Telop,,0,0,0,,{body}\n"
        )
    ass_path = workdir / "captions.ass"
    ass_path.write_text("".join(lines), encoding="utf-8")
    return ass_path


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--pptx", required=True)
    parser.add_argument("--narration", required=True)
    parser.add_argument("--script", required=True, help="スライド番号×ナレーション文の表を含むMarkdown")
    parser.add_argument("--workdir", required=True)
    parser.add_argument("--whisper-model",
                         default=str(Path.home() / ".cache/whisper-cpp-models/ggml-large-v3-turbo.bin"))
    parser.add_argument("--width", type=int, default=1920)
    parser.add_argument("--height", type=int, default=1080)
    parser.add_argument("--fps", type=int, default=25)
    parser.add_argument("--telop-font-size", type=int, default=42)
    parser.add_argument("--telop-bg-color", default="#8C4A35",
                         help="テロップ背景色（16進カラーコード）。黒(#000000)は暗い背景動画では"
                              "視認性が落ちるため非推奨。suggest_accent_color.pyでスライドから抽出した"
                              "アクセントカラーの使用を推奨")
    parser.add_argument("--telop-max-line-chars", type=int, default=26)
    args = parser.parse_args()

    pptx_path = Path(args.pptx).resolve()
    narration_path = Path(args.narration).resolve()
    script_path = Path(args.script).resolve()
    workdir = Path(args.workdir).resolve()
    workdir.mkdir(parents=True, exist_ok=True)

    print("[1/6] PPTXをスライド画像に変換中...")
    slide_pngs = convert_pptx_to_slides(pptx_path, workdir, args.width, args.height)
    print(f"  → {len(slide_pngs)}枚")

    script_lines = parse_script_table(script_path.read_text(encoding="utf-8"))
    if len(script_lines) != len(slide_pngs):
        print(
            f"警告: 台本の行数({len(script_lines)})とスライド枚数({len(slide_pngs)})が一致していません。"
            "スライド切り替えタイミングがずれる可能性があります。",
            file=sys.stderr,
        )

    print("[2/6] ナレーション音声を16kHz/monoに変換中...")
    wav_path = to_16k_mono_wav(narration_path, workdir)
    total_duration = get_duration(narration_path)

    print("[3/6] whisper.cppで文字起こし中...")
    segments = transcribe(wav_path, Path(args.whisper_model).expanduser(), workdir)
    print(f"  → {len(segments)}セグメント")

    print("[4/6] 台本と文字起こし結果を照合し、スライド切り替えタイミングを推定中...")
    timings = match_slide_timings(segments, script_lines, total_duration)
    (workdir / "slide_timing.json").write_text(
        json.dumps(timings, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    for t in timings:
        dur = t["end"] - t["start"]
        flag = "  ← 短すぎる可能性あり。要確認" if dur < 1.0 else ""
        print(f"  スライド{t['slide']:>2}: {t['start']:>7.2f}s - {t['end']:>7.2f}s ({dur:>5.2f}s){flag}")

    print("[5/6] スライドショー背景動画を作成中...")
    background = build_slideshow(slide_pngs, timings, args.width, args.height, args.fps, workdir)
    print(f"  → {background}")

    print("[6/6] テロップ字幕(ASS)を作成中...")
    captions = build_captions_ass(
        segments, workdir, args.width, args.height,
        args.telop_font_size, args.telop_bg_color, args.telop_max_line_chars,
    )
    print(f"  → {captions}")

    print("\n完了。次は compose_video.py で背景・ワイプ・テロップ・ナレーションを合成してください。")
    print("スライド切り替えタイミングは推定値です。background.mp4から数フレーム抜き出して目視確認を推奨します。")


if __name__ == "__main__":
    main()
