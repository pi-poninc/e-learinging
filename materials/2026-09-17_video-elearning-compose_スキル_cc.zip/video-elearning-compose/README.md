# video-elearning-compose ── インストールと使い方

Claude Code 用スキル。ナレーション音声（FishAudio等のTTSや実録音）＋PowerPointスライド＋（任意で）ワイプ動画（HeyGenのリップシンク動画や画面録画）から、スライド＋ワイプ＋テロップ入りのeラーニング動画を自動合成します。

## インストール

このフォルダ（`video-elearning-compose/`）をまるごと次の場所に置くだけです。

```
~/.claude/skills/video-elearning-compose/
```

Claude Code を起動し直すと、「このPowerPointとこの音声を動画にして」「eラーニング動画を作って」などの依頼で自動的に使われます。手動で呼ぶ場合は `/video-elearning-compose` です。

## 必要なもの（macOS想定）

| ツール | 用途 | 入れ方 |
|---|---|---|
| ffmpeg / ffprobe | 動画合成 | `brew install ffmpeg` |
| LibreOffice（`soffice`） | PPTX→PDF | `brew install --cask libreoffice` |
| Poppler（`pdftoppm`） | PDF→PNG | `brew install poppler` |
| whisper.cpp（`whisper-cli`） | ナレーション文字起こし | `brew install whisper-cpp` |
| whisperモデル | 文字起こし用 | 下記 |
| Python 3 ＋ Pillow | スクリプト実行・色抽出 | `pip3 install pillow` |

whisperモデルは既定で `~/.cache/whisper-cpp-models/ggml-large-v3-turbo.bin` を見にいきます。

```
mkdir -p ~/.cache/whisper-cpp-models
curl -L -o ~/.cache/whisper-cpp-models/ggml-large-v3-turbo.bin \
  https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo.bin
```

別の場所に置く場合は `prepare_assets.py --whisper-model <パス>` で指定できます。

## 入力として用意するもの

1. **PPTXスライド**
2. **ナレーション音声**（mp3/wav）。FishAudio等で作る場合、英字表記（Claude Code、MCP など）はカタカナに直したテキストを読ませると発音が安定します
3. **台本Markdown**：`| # | スライド | ナレーション |` の表。**行数＝スライド枚数**にそろえること（ここがズレると切り替えタイミングが崩れます）
4. **ワイプ動画**（任意）：HeyGenのリップシンク動画、画面録画など

詳しい手順・レイアウトの考え方・つまずきポイントは `SKILL.md` を参照してください。

## 動作確認済み環境

macOS（Apple Silicon）、ffmpeg 7系、whisper.cpp large-v3-turbo、LibreOffice 24系。2026-08に4本（各3〜4分・1920×1080）の制作で使用。
