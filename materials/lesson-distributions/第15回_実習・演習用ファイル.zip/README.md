# 第15回 実習・演習用ファイル案内

## この回で行うこと

会議メモと問い合わせ記録を組み合わせ、根拠表・提案骨子・フォローアップ文案を作ります。

## 同梱ファイル

- `training-sandbox/inputs/meeting_notes.txt`
- `training-sandbox/inputs/sales_data.csv`
- `training-sandbox/outputs/README.md`
- `training-sandbox/README.md`
- `training-sandbox/working/README.md`

## 内容確認と注意事項

- 会議メモの優先対象は、初回ログイン、請求書の確認、パスワード再設定です。
- 問い合わせデータは12件で、3カテゴリはいずれも3件、loginとbillingは未対応1件、password_resetは未対応0件です。
- 完成成果物や処理メモは受講者がoutputsへ生成します。
- 同梱データはすべて研修用の合成データで、実在する個人・顧客・認証情報を含みません。
- 動画で例示するだけの危険なファイルや、受講者が作るべき完成成果物は同梱していません。

## 使い方

ZIPを展開し、`training-sandbox` が含まれる回では、そのフォルダをプロジェクトフォルダとして選択してください。
元データを上書きせず、生成物は `outputs` に保存してください。
