# 第8回 実習・演習用ファイル案内

## この回で行うこと

問い合わせデータから初稿を作り、件数・平均・欠損処理を検証して修正します。

## 同梱ファイル

- `training-sandbox/inputs/sales_data.csv`
- `training-sandbox/outputs/README.md`
- `training-sandbox/README.md`
- `training-sandbox/working/README.md`

## 内容確認と注意事項

- 正しい基準値は、12件、対応時間の欠損1件、平均の分母11件、全体平均約17.2分です。
- 同梱データはすべて研修用の合成データで、実在する個人・顧客・認証情報を含みません。
- 動画で例示するだけの危険なファイルや、受講者が作るべき完成成果物は同梱していません。

## 使い方

ZIPを展開し、`training-sandbox` が含まれる回では、そのフォルダをプロジェクトフォルダとして選択してください。
元データを上書きせず、生成物は `outputs` に保存してください。
