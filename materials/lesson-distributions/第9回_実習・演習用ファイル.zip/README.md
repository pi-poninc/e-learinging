# 第9回 実習・演習用ファイル案内

## この回で行うこと

会議メモとブランドガイドを使い、目的に合う6枚のPowerPointを作成します。

## 同梱ファイル

- `training-sandbox/inputs/brand_guide.txt`
- `training-sandbox/inputs/meeting_notes.txt`
- `training-sandbox/outputs/README.md`
- `training-sandbox/README.md`
- `training-sandbox/working/README.md`

## 内容確認と注意事項

- 完成PowerPointは正解例として同梱していません。受講者がoutputsへ生成します。
- 同梱データはすべて研修用の合成データで、実在する個人・顧客・認証情報を含みません。
- 動画で例示するだけの危険なファイルや、受講者が作るべき完成成果物は同梱していません。

## 使い方

ZIPを展開し、`training-sandbox` が含まれる回では、そのフォルダをプロジェクトフォルダとして選択してください。
元データを上書きせず、生成物は `outputs` に保存してください。
