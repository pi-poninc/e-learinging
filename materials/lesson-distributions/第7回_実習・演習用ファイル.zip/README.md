# 第7回 実習・演習用ファイル案内

## この回で行うこと

背景・目的・入力・成果物・制約・完了条件の6要素で依頼を具体化します。

## 同梱ファイル

- `training-sandbox/inputs/brand_guide.txt`
- `training-sandbox/inputs/meeting_notes.txt`
- `training-sandbox/outputs/README.md`
- `training-sandbox/README.md`
- `training-sandbox/working/README.md`

## 内容確認と注意事項

- meeting_notes.txtは提案書依頼の実演、brand_guide.txtは商品紹介文の演習に使います。
- 同梱データはすべて研修用の合成データで、実在する個人・顧客・認証情報を含みません。
- 動画で例示するだけの危険なファイルや、受講者が作るべき完成成果物は同梱していません。

## 使い方

ZIPを展開し、`training-sandbox` が含まれる回では、そのフォルダをプロジェクトフォルダとして選択してください。
元データを上書きせず、生成物は `outputs` に保存してください。
