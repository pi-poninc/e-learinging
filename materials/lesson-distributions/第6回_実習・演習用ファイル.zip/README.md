# 第6回 実習・演習用ファイル案内

## この回で行うこと

3つの入力資料の役割を分け、出典付きの要点メモをoutputsへ保存します。

## 同梱ファイル

- `training-sandbox/inputs/brand_guide.txt`
- `training-sandbox/inputs/meeting_notes.txt`
- `training-sandbox/inputs/sales_data.csv`
- `training-sandbox/outputs/README.md`
- `training-sandbox/README.md`
- `training-sandbox/working/README.md`

## 内容確認と注意事項

- outputsには完成例を入れていません。受講者が生成した成果物を保存してください。
- 同梱データはすべて研修用の合成データで、実在する個人・顧客・認証情報を含みません。
- 動画で例示するだけの危険なファイルや、受講者が作るべき完成成果物は同梱していません。

## 使い方

ZIPを展開し、`training-sandbox` が含まれる回では、そのフォルダをプロジェクトフォルダとして選択してください。
元データを上書きせず、生成物は `outputs` に保存してください。
