# outputs

Google Driveから取得した会議メモの要約を保存します。正解例は入っていません。
