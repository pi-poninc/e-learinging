# training-sandbox（第13回）

Google Driveから取得した要約をローカル保存するためのフォルダです。
