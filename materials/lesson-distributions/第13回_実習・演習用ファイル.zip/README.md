# 第13回 実習・演習用ファイル案内

## この回で行うこと

Google Driveの研修用会議メモを読み取り、要約をローカルのoutputsへ保存します。

## 同梱ファイル

- `gdrive-training-materials/meeting_notes_for_drive.md`
- `gdrive-training-materials/README.md`
- `training-sandbox/outputs/README.md`
- `training-sandbox/README.md`

## 内容確認と注意事項

- meeting_notes_for_drive.mdはGoogle Driveへ配置する合成データです。
- Drive側の更新、共有設定変更、外部送信は行いません。
- 同梱データはすべて研修用の合成データで、実在する個人・顧客・認証情報を含みません。
- 動画で例示するだけの危険なファイルや、受講者が作るべき完成成果物は同梱していません。

## 使い方

ZIPを展開し、`training-sandbox` が含まれる回では、そのフォルダをプロジェクトフォルダとして選択してください。
元データを上書きせず、生成物は `outputs` に保存してください。
