# gdrive-training-materials（第13回）

`meeting_notes_for_drive.md` は研修専用Google Driveへ配置する合成データです。
読み取り対象をこのファイルに限定し、取得した要約はローカルの `training-sandbox/outputs` へ保存してください。
Google Drive側の更新、共有設定変更、外部送信は行いません。
