# 第14回 実習・演習用ファイル案内

## この回で行うこと

成功済みの手順をSkillとして登録し、別データで再実行します。

## 同梱ファイル

- `training-sandbox/inputs/meeting_notes.txt`
- `training-sandbox/inputs/sales_data_202609.csv`
- `training-sandbox/inputs/sales_data.csv`
- `training-sandbox/outputs/README.md`
- `training-sandbox/README.md`
- `training-sandbox/working/README.md`

## 内容確認と注意事項

- CSV分析Skillはsales_data.csvで手順を確認し、sales_data_202609.csvで再現性を試します。
- 演習ではmeeting_notes.txtを使う会議メモ整理Skillを設計・実行します。
- Skillファイルと完成結果は受講者が作るため、正解例は同梱していません。
- 同梱データはすべて研修用の合成データで、実在する個人・顧客・認証情報を含みません。
- 動画で例示するだけの危険なファイルや、受講者が作るべき完成成果物は同梱していません。

## 使い方

ZIPを展開し、`training-sandbox` が含まれる回では、そのフォルダをプロジェクトフォルダとして選択してください。
元データを上書きせず、生成物は `outputs` に保存してください。
