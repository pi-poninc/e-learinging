# 第12回 実習・演習用ファイル案内

## この回で行うこと

同じ事実シートから、用途の異なる社内向け成果物を作り分けます。

## 同梱ファイル

- `training-sandbox/inputs/anshin_help_fact_sheet.txt`
- `training-sandbox/inputs/brand_guide.txt`
- `training-sandbox/outputs/README.md`
- `training-sandbox/README.md`
- `training-sandbox/working/README.md`

## 内容確認と注意事項

- 確認済みの事実は、提供開始日2026年11月2日、社内利用者向け、追加費用なしです。
- 社外向け提供時期は未確認のまま扱います。
- 同梱データはすべて研修用の合成データで、実在する個人・顧客・認証情報を含みません。
- 動画で例示するだけの危険なファイルや、受講者が作るべき完成成果物は同梱していません。

## 使い方

ZIPを展開し、`training-sandbox` が含まれる回では、そのフォルダをプロジェクトフォルダとして選択してください。
元データを上書きせず、生成物は `outputs` に保存してください。
