# 第10回 実習・演習用ファイル案内

## この回で行うこと

8月データを点検・集計し、9月データで同じ手順を再実行します。

## 同梱ファイル

- `training-sandbox/inputs/sales_data_202609.csv`
- `training-sandbox/inputs/sales_data.csv`
- `training-sandbox/outputs/README.md`
- `training-sandbox/README.md`
- `training-sandbox/working/README.md`

## 内容確認と注意事項

- 8月は12件、メール5件・チャット4件・電話3件、欠損1件です。
- 9月は10件、チャット5件・メール3件・電話2件、欠損1件です。
- 同梱データはすべて研修用の合成データで、実在する個人・顧客・認証情報を含みません。
- 動画で例示するだけの危険なファイルや、受講者が作るべき完成成果物は同梱していません。

## 使い方

ZIPを展開し、`training-sandbox` が含まれる回では、そのフォルダをプロジェクトフォルダとして選択してください。
元データを上書きせず、生成物は `outputs` に保存してください。
